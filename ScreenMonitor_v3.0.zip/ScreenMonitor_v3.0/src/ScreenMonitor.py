# -*- coding: utf-8 -*- #
'''
Screen Monitor Version 3.0
By 2326 @ 2015-08-20
'''
from automaton import *
from cStringIO import StringIO
from PIL import Image
from PyQt4 import QtCore, QtGui
from PyQt4.QtCore import pyqtSignature
from PyQt4.QtGui import QDialog
from string import Template
from systray import *
from multiprocessing import *
import ctypes
import os
import sys
import threading
import time
import Tkinter
import win32clipboard
import win32gui
try:
	_fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
	def _fromUtf8(s):
		return s

class RECT(ctypes.Structure):
		_fields_ = [('left', ctypes.c_long), ('top', ctypes.c_long), ('right', ctypes.c_long), ('bottom', ctypes.c_long)]
		def __str__(self):
			return str((self.left, self.top, self.right, self.bottom))

g_root = Tkinter.Tk()
g_scSize = [g_root.winfo_screenwidth(), g_root.winfo_screenheight()]
g_scRegion = None # screen region: 1 = full screen, 2 = current window, 3 = mouse selected region
g_prType = None # print type: 1 = fixed time interval, 2 = on keyboard event
g_psInterval = None # print screen time interval
g_psHotkey = None # print screen hot key
g_dir = None # saving directory
g_rect = Array('i', range(4))
sc = Screen()
lis = Listener()
lisAgent = None
g_app, g_systrayDialog = None, None
g_settingsDialog = None
g_helpDialog = None
g_ppr = None
filenameTemp = None
tmp_scRegion, tmp_prType, tmp_psInterval, tmp_psHotkey, tmp_dir = None, None, None, None, None


########## eric6's PyQt enbeded GUI code ##########
try:
	_encoding = QtGui.QApplication.UnicodeUTF8
	def _translate(context, text, disambig):
		return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
	def _translate(context, text, disambig):
		return QtGui.QApplication.translate(context, text, disambig)

class GuiHelpBasic(object):
	def setupUi(self, Dialog):
		Dialog.setObjectName(_fromUtf8("Dialog"))
		Dialog.setWindowModality(QtCore.Qt.NonModal)
		Dialog.setEnabled(True)
		Dialog.resize(514, 120)
		Dialog.setMinimumSize(QtCore.QSize(514, 120))
		Dialog.setMaximumSize(QtCore.QSize(514, 120))
		Dialog.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
		icon = QtGui.QIcon()
		icon.addPixmap(QtGui.QPixmap(_fromUtf8(r'res\appIcon.ico')), QtGui.QIcon.Normal, QtGui.QIcon.Off)
		Dialog.setWindowIcon(icon)
		Dialog.setAutoFillBackground(False)
		Dialog.setSizeGripEnabled(False)
		Dialog.setWindowFlags(Qt.SubWindow) # IMPORT !!!
		self.pushButton = QtGui.QPushButton(Dialog)
		self.pushButton.setGeometry(QtCore.QRect(205, 80, 93, 28))
		self.pushButton.setObjectName(_fromUtf8("pushButton"))
		self.label = QtGui.QLabel(Dialog)
		self.label.setGeometry(QtCore.QRect(10, 0, 551, 71))
		font = QtGui.QFont()
		font.setPointSize(11)
		self.label.setFont(font)
		self.label.setObjectName(_fromUtf8("label"))

		self.retranslateUi(Dialog)
		# QtCore.QObject.connect(self.pushButton, QtCore.SIGNAL(_fromUtf8("clicked()")), Dialog.hide)
		QtCore.QMetaObject.connectSlotsByName(Dialog)

	def retranslateUi(self, Dialog):
		Dialog.setWindowTitle(_translate("Dialog", "Help", None))
		self.pushButton.setText(_translate("Dialog", "OK", None))
		self.label.setText(_translate("Dialog", "Screen Monitor is a program that captures specified \n"
"screen region at a given rate or on keyboard event. \n"
"Please use Settings to config the capturing parameters.", None))

	def mousePressEvent(self, event):
		if event.button() == Qt.LeftButton:
			self.dragPosition = event.globalPos() - self.frameGeometry().topLeft()
			QtGui.QApplication.postEvent(self, QtCore.QEvent(174))
			event.accept()
 
	def mouseMoveEvent(self, event):
		if event.buttons() == Qt.LeftButton:
			self.move(event.globalPos() - self.dragPosition)
			event.accept()

class GuiHelp(QDialog, GuiHelpBasic):
	def __init__(self, parent = None):
		QDialog.__init__(self, parent)
		self.setupUi(self)

	@pyqtSignature("")
	def on_pushButton_clicked(self):
		self.close()


class GuiSettingsBasic(object):
	def setupUi(self, Dialog):
		Dialog.setObjectName(_fromUtf8("Dialog"))
		Dialog.setEnabled(True)
		Dialog.resize(642, 360)
		Dialog.setMinimumSize(QtCore.QSize(642, 360))
		Dialog.setMaximumSize(QtCore.QSize(642, 360))
		icon = QtGui.QIcon()
		icon.addPixmap(QtGui.QPixmap(_fromUtf8(r'res\appIcon.ico')), QtGui.QIcon.Normal, QtGui.QIcon.Off)
		Dialog.setWindowIcon(icon)
		Dialog.setSizeGripEnabled(False)
		Dialog.setWindowFlags(Qt.SubWindow) # IMPORT !!!
		Dialog.setModal(False)
		self.gbScreenRegion = QtGui.QGroupBox(Dialog)
		self.gbScreenRegion.setGeometry(QtCore.QRect(10, 20, 621, 80))
		font = QtGui.QFont()
		font.setFamily(_fromUtf8("SimSun-ExtB"))
		font.setPointSize(12)
		font.setStyleStrategy(QtGui.QFont.PreferAntialias)
		self.gbScreenRegion.setFont(font)
		self.gbScreenRegion.setAcceptDrops(False)
		self.gbScreenRegion.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignVCenter)
		self.gbScreenRegion.setFlat(False)
		self.gbScreenRegion.setCheckable(False)
		self.gbScreenRegion.setObjectName(_fromUtf8("gbScreenRegion"))
		self.rbFullScreen = QtGui.QRadioButton(self.gbScreenRegion)
		self.rbFullScreen.setGeometry(QtCore.QRect(30, 40, 151, 19))
		font = QtGui.QFont()
		font.setPointSize(10)
		self.rbFullScreen.setFont(font)
		self.rbFullScreen.setObjectName(_fromUtf8("rbFullScreen"))
		self.rbCurrentWindow = QtGui.QRadioButton(self.gbScreenRegion)
		self.rbCurrentWindow.setGeometry(QtCore.QRect(190, 40, 151, 19))
		font = QtGui.QFont()
		font.setPointSize(10)
		self.rbCurrentWindow.setFont(font)
		self.rbCurrentWindow.setObjectName(_fromUtf8("rbCurrentWindow"))
		self.rbMouseSelectedRegion = QtGui.QRadioButton(self.gbScreenRegion)
		self.rbMouseSelectedRegion.setGeometry(QtCore.QRect(380, 40, 221, 19))
		font = QtGui.QFont()
		font.setPointSize(10)
		self.rbMouseSelectedRegion.setFont(font)
		self.rbMouseSelectedRegion.setObjectName(_fromUtf8("rbMouseSelectedRegion"))
		self.gbPrintMode = QtGui.QGroupBox(Dialog)
		self.gbPrintMode.setGeometry(QtCore.QRect(10, 110, 621, 81))
		font = QtGui.QFont()
		font.setFamily(_fromUtf8("SimSun-ExtB"))
		font.setPointSize(12)
		font.setStyleStrategy(QtGui.QFont.PreferAntialias)
		self.gbPrintMode.setFont(font)
		self.gbPrintMode.setObjectName(_fromUtf8("gbPrintMode"))
		self.leSeconds = QtGui.QLineEdit(self.gbPrintMode)
		self.leSeconds.setGeometry(QtCore.QRect(110, 40, 41, 24))
		self.leSeconds.setObjectName(_fromUtf8("leSeconds"))
		self.leHotkey = QtGui.QLineEdit(self.gbPrintMode)
		self.leHotkey.setGeometry(QtCore.QRect(395, 40, 191, 25))
		self.leHotkey.setObjectName(_fromUtf8("leHotkey"))
		self.rbEverySeconds = QtGui.QRadioButton(self.gbPrintMode)
		self.rbEverySeconds.setGeometry(QtCore.QRect(30, 40, 211, 19))
		font = QtGui.QFont()
		font.setPointSize(10)
		self.rbEverySeconds.setFont(font)
		self.rbEverySeconds.setObjectName(_fromUtf8("rbEverySeconds"))
		self.rbOnHotkey = QtGui.QRadioButton(self.gbPrintMode)
		self.rbOnHotkey.setGeometry(QtCore.QRect(280, 40, 211, 19))
		font = QtGui.QFont()
		font.setPointSize(10)
		self.rbOnHotkey.setFont(font)
		self.rbOnHotkey.setObjectName(_fromUtf8("rbOnHotkey"))
		self.rbOnHotkey.raise_()
		self.rbEverySeconds.raise_()
		self.leSeconds.raise_()
		self.leHotkey.raise_()
		self.gbDirectory = QtGui.QGroupBox(Dialog)
		self.gbDirectory.setGeometry(QtCore.QRect(10, 200, 621, 91))
		font = QtGui.QFont()
		font.setFamily(_fromUtf8("SimSun-ExtB"))
		font.setPointSize(12)
		font.setStyleStrategy(QtGui.QFont.PreferAntialias)
		self.gbDirectory.setFont(font)
		self.gbDirectory.setObjectName(_fromUtf8("gbDirectory"))
		self.leDirectory = QtGui.QLineEdit(self.gbDirectory)
		self.leDirectory.setGeometry(QtCore.QRect(30, 40, 511, 21))
		self.leDirectory.setObjectName(_fromUtf8("leDirectory"))
		self.leDirectory.setReadOnly(True)
		self.btnCD = QtGui.QPushButton(self.gbDirectory)
		self.btnCD.setGeometry(QtCore.QRect(560, 40, 31, 21))
		font = QtGui.QFont()
		font.setPointSize(9)
		self.btnCD.setFont(font)
		self.btnCD.setObjectName(_fromUtf8("btnCD"))
		self.btnOK = QtGui.QPushButton(Dialog)
		self.btnOK.setGeometry(QtCore.QRect(418, 310, 93, 28))
		self.btnOK.setObjectName(_fromUtf8("btnOK"))
		self.btnCancel = QtGui.QPushButton(Dialog)
		self.btnCancel.setGeometry(QtCore.QRect(538, 310, 93, 28))
		self.btnCancel.setObjectName(_fromUtf8("btnCancel"))

		self.retranslateUi(Dialog)
		QtCore.QMetaObject.connectSlotsByName(Dialog)
		Dialog.setTabOrder(self.rbFullScreen, self.rbCurrentWindow)
		Dialog.setTabOrder(self.rbCurrentWindow, self.rbMouseSelectedRegion)
		Dialog.setTabOrder(self.rbMouseSelectedRegion, self.rbEverySeconds)
		Dialog.setTabOrder(self.rbEverySeconds, self.leSeconds)
		Dialog.setTabOrder(self.leSeconds, self.rbOnHotkey)
		Dialog.setTabOrder(self.rbOnHotkey, self.leHotkey)
		Dialog.setTabOrder(self.leHotkey, self.leDirectory)
		Dialog.setTabOrder(self.leDirectory, self.btnCD)

	def retranslateUi(self, Dialog):
		Dialog.setWindowTitle(_translate("Dialog", "Settings", None))
		self.gbScreenRegion.setTitle(_translate("Dialog", "Screen Region", None))
		self.rbFullScreen.setText(_translate("Dialog", "Full Screen", None))
		self.rbCurrentWindow.setText(_translate("Dialog", "Current Window", None))
		self.rbMouseSelectedRegion.setText(_translate("Dialog", "Mouse Selected Region", None))
		self.gbPrintMode.setTitle(_translate("Dialog", "Print Mode", None))
		self.rbEverySeconds.setText(_translate("Dialog", "Every	      Seconds", None))
		self.rbOnHotkey.setText(_translate("Dialog", "On Hotkey", None))
		self.gbDirectory.setTitle(_translate("Dialog", "Directory", None))
		self.btnCD.setText(_translate("Dialog", "...", None))
		self.btnOK.setText(_translate("Dialog", "OK", None))
		self.btnCancel.setText(_translate("Dialog", "Cancel", None))

	def mousePressEvent(self, event):
		if event.button() == Qt.LeftButton:
			self.dragPosition = event.globalPos() - self.frameGeometry().topLeft()
			QtGui.QApplication.postEvent(self, QtCore.QEvent(174))
			event.accept()
 
	def mouseMoveEvent(self, event):
		if event.buttons() == Qt.LeftButton:
			self.move(event.globalPos() - self.dragPosition)
			event.accept()


class GuiSettings(QDialog, GuiSettingsBasic):
	def __init__(self, parent = None):
		QDialog.__init__(self, parent)
		self.setupUi(self)
		self.init_widgets()

	def init_widgets(self):
		global g_scRegion, g_prType, g_psInterval, g_psHotkey, g_dir
		global tmp_scRegion, tmp_prType, tmp_psInterval, tmp_psHotkey, tmp_dir
		tmp_scRegion, tmp_prType, tmp_psInterval, tmp_psHotkey, tmp_dir = g_scRegion, g_prType, g_psInterval, g_psHotkey, g_dir
		self.rbFullScreen.setChecked(tmp_scRegion == 1)
		self.rbCurrentWindow.setChecked(tmp_scRegion == 2)
		self.rbMouseSelectedRegion.setChecked(tmp_scRegion == 3)
		self.rbEverySeconds.setChecked(tmp_prType == 1)
		self.rbOnHotkey.setChecked(tmp_prType == 2)
		self.leSeconds.setText(str(tmp_psInterval))
		self.leHotkey.setText(__VK2str__(tmp_psHotkey))
		self.leDirectory.setText(tmp_dir)

	@pyqtSignature("")
	def on_btnCD_clicked(self):
		global tmp_dir
		tmp_dir = NormPath(str(QtGui.QFileDialog.getExistingDirectory(self, 'Open directory', '')))
		self.leDirectory.setText(tmp_dir)

	@pyqtSignature("")
	def on_btnOK_clicked(self):
		global g_scRegion, g_prType, g_psInterval, g_psHotkey, g_dir
		global tmp_scRegion, tmp_prType, tmp_psInterval, tmp_psHotkey, tmp_dir
		try:
			tmp_psInterval = float(str(self.leSeconds.text())) # get time interval
		except:
			self.leSeconds.setText('')
			return
		try:
			tmp_psHotkey = VK_CODE[str(self.leHotkey.text())] # get hotkey
		except:
			self.leHotkey.setText('')
			return
		try:
			tmp_dir = NormPath(str(self.leDirectory.text())) # get dir
		except:
			self.leDirectory.setText('')
			return # TODO: message box report error / highlight error attributes
		isSameDir = (g_dir == tmp_dir)
		g_scRegion, g_prType, g_psInterval, g_psHotkey, g_dir = tmp_scRegion, tmp_prType, tmp_psInterval, tmp_psHotkey, tmp_dir
		if not isSameDir:
			__PrepareDir__()
			global filenameTemp
			filenameTemp = Template(g_dir + '${year}${month}${day}_${hour}${minute}${second}.jpg')
		__SaveSettings__() # save default settings to config.ini
		self.close()

	@pyqtSignature("")
	def on_btnCancel_clicked(self):
		global g_scRegion
		if g_scRegion == 3:
			self.rbEverySeconds.setEnabled(False)
			self.leSeconds.setEnabled(False)
		else:
			self.rbEverySeconds.setEnabled(True)
			self.leSeconds.setEnabled(True)
		self.close()

	@pyqtSignature("")
	def on_rbFullScreen_clicked(self):
		global tmp_scRegion
		tmp_scRegion = 1
		self.rbEverySeconds.setEnabled(True)
		self.leSeconds.setEnabled(True)

	@pyqtSignature("")
	def on_rbCurrentWindow_clicked(self):
		global tmp_scRegion
		tmp_scRegion = 2
		self.rbEverySeconds.setEnabled(True)
		self.leSeconds.setEnabled(True)

	@pyqtSignature("")
	def on_rbMouseSelectedRegion_clicked(self):
		global tmp_scRegion, tmp_prType
		tmp_scRegion = 3
		tmp_prType = 2
		self.rbEverySeconds.setEnabled(False)
		self.leSeconds.setEnabled(False)
		self.rbOnHotkey.setChecked(True)

	@pyqtSignature("")
	def on_rbOnHotkey_clicked(self):
		global tmp_prType
		tmp_prType = 2

	@pyqtSignature("")
	def on_rbEverySeconds_clicked(self):
		global tmp_prType
		tmp_prType = 1
########## eric6's PyQt embedded GUI code ##########

########## thread routines and callbacks ###########
# always-on printer thread routine
def PrinterRoutine():
	global g_scRegion, g_prType, g_psInterval
	while 1:
		if g_prType == 1:
			if g_scRegion == 1: # print full screen
				PrintAndSave()
			elif g_scRegion == 2: # print current window
				rect = RECT()
				HWND = win32gui.GetForegroundWindow()
				ctypes.windll.user32.GetWindowRect(HWND,ctypes.byref(rect))
				rect.left = max(rect.left, 0)
				rect.top = max(rect.top, 0)
				global g_scSize
				rect.right = min(rect.right, g_scSize[0])
				rect.bottom = min(rect.bottom, g_scSize[1])
				PrintAndSave([rect.left, rect.top, rect.right, rect.bottom])
			time.sleep(g_psInterval)
		else:
			time.sleep(1)

# systray thread routine
def SystrayRoutine():
	global g_app, g_systrayDialog
	g_app = QtGui.QApplication([])
	g_systrayDialog = SysTray(icon = r'res\appIcon.ico', onQuit = OnQuit, options = [('Settings', OnSettings), ('Help', OnHelp)])
	g_systrayDialog.show()
	sys.exit(g_app.exec_())

# systray callback 1
def OnSettings(inst):
	global g_settingsDialog
	if g_settingsDialog == None:
		g_settingsDialog = GuiSettings()
	else:
		g_settingsDialog.init_widgets()
	if not g_settingsDialog.isVisible():
		g_settingsDialog.show()

# systray callback 2
def OnHelp(inst):
	global g_helpDialog
	if g_helpDialog == None:
		g_helpDialog = GuiHelp()
	if not g_helpDialog.isVisible():
		g_helpDialog.show()

# systray callback 3
def OnQuit(inst):
	global g_ppr
	if g_ppr != None:
		g_ppr.terminate()

# on-mouse-event printer routine
def PPrinterRoutine():
	global filenameTemp
	fid = open('config.ini', 'r')
	for i in range(6):
		fid.readline()
	filenameTemp = Template(NormPath(fid.readline().strip().split('=', 1)[1]) + '${year}${month}${day}_${hour}${minute}${second}.jpg')
	fid.close()
	lis = Listener()
	lis.Configure('MouseEventCallBack', OnMouseEvent)
	lisA = lis.Start()
	lisA.join()

# listener thread mouse event callback
def OnMouseEvent(event):
	global g_rect
	if event.Message == 513: # left button down
		g_rect[0], g_rect[1] = event.Position[0], event.Position[1]
		return False
	elif event.Message == 514: # left button up
		g_rect[2], g_rect[3] = event.Position[0], event.Position[1]
		PrintAndSave(g_rect) # print and save selected screen region
		sys.exit()
	return True

# listener thread keyboard event callback
def OnKeyboardEvent(event):
	global g_scRegion, g_psHotkey, g_prType
	if event.KeyID == g_psHotkey and g_prType == 2: # on keyboard event and key pressed
		if g_scRegion == 3: # print mouse selected region
			global g_dir, g_ppr
			g_ppr = Process(target = PPrinterRoutine)
			g_ppr.start()
			g_ppr.join()
		elif g_scRegion == 2: # print current window
			rect = RECT()
			HWND = win32gui.GetForegroundWindow()
			ctypes.windll.user32.GetWindowRect(HWND,ctypes.byref(rect))
			rect.left = max(rect.left, 0)
			rect.top = max(rect.top, 0)
			global g_scSize
			rect.right = min(rect.right, g_scSize[0])
			rect.bottom = min(rect.bottom, g_scSize[1])
			PrintAndSave([rect.left, rect.top, rect.right, rect.bottom])
		elif g_scRegion == 1: # print full screen
			PrintAndSave()
		return False
	return True
########## thread routines and callbacks ###########

# init settings, saving directory
def Init():
	__LoadSettings__()
	__PrepareDir__()

# load default settings
def __LoadSettings__():
	global g_scRegion, g_prType, g_psInterval, g_psHotkey, g_dir
	try:
		fid = open('config.ini', 'r')
		fid.readline(), fid.readline()
		g_scRegion = int(fid.readline().strip().split('=', 1)[1])
		g_prType   = int((fid.readline().strip().split('=', 1))[1])
		g_psInterval = float((fid.readline().strip().split('=', 1))[1])
		g_psHotkey = VK_CODE[(fid.readline().strip().split('=', 1))[1]]
		g_dir	   = NormPath(fid.readline().strip().split('=', 1)[1])
		fid.close()
	except:
		g_scRegion, g_prType, g_psInterval, g_psHotkey, g_dir = 1, 1, 5.0, VK_CODE['print_screen'], NormPath('PrintedScreen')
	global filenameTemp
	filenameTemp = Template(g_dir + '${year}${month}${day}_${hour}${minute}${second}.jpg')

# save default settings
def __SaveSettings__():
	global g_scRegion, g_prType, g_psInterval, g_psHotkey, g_dir
	try:
		fid = open('config.ini', 'w')
		fid.write('Screen Monitor Version 3.0\n# default settings, order of parameters matters')
		fid.write('\ng_scRegion=' + str(g_scRegion))
		fid.write('\ng_prType=' + str(g_prType))
		fid.write('\ng_psInterval=' + str(g_psInterval))
		fid.write('\ng_psHotkey=' + __VK2str__(g_psHotkey))
		fid.write('\ng_dir=' + str(g_dir))
		fid.close()
	except:
		print 'Screen Monitor encountered error [403]: Can\'t save default parameters. Ignored.'

# prepare saving directory
def __PrepareDir__():
	global g_dir
	if not os.path.exists(g_dir) or os.path.isfile(g_dir):
		os.makedirs(g_dir)

def __VK2str__(VKHotkey):
	for i in VK_CODE.keys():
		if VK_CODE[i] == VKHotkey:
			return i
	return None

# how to run the script
def Usage():
	return 'Usage: python ScreenMonitor2.py'

# print and save screen
def PrintAndSave(rect = None):
	try:
		if rect == None:
			sc.PrintScreen()
		else:
			if rect[0] > rect[2]:
				rect[0], rect[2] = rect[2], rect[0]
			if rect[1] > rect[3]:
				rect[1], rect[3] = rect[3], rect[1]
			sc.PrintScreen(rect = rect)
	except:
		print 'Screen Monitor encountered error [401]: Can\'t print screen. Ignored.'
	ct = time.localtime(time.time())
	try:
		fnTmp = filenameTemp.substitute(year = ct.tm_year, month = str(ct.tm_mon).zfill(2), day = str(ct.tm_mday).zfill(2),\
										hour = str(ct.tm_hour).zfill(2), minute = str(ct.tm_min).zfill(2), second = str(ct.tm_sec).zfill(2))
		sc.Save(fnTmp)
		im = Image.open(fnTmp)
		output = StringIO()
		im.convert("RGB").save(output, "BMP")
		data = output.getvalue()[14:]
		output.close()
		SendToClipboard(win32clipboard.CF_DIB, data)
	except:
		print 'Screen Monitor encountered error [402]: Can\'t save image file. Ignored.'

# send captured screen region to clipboard
def SendToClipboard(clip_type, data):
	win32clipboard.OpenClipboard()
	win32clipboard.EmptyClipboard()
	win32clipboard.SetClipboardData(clip_type, data)
	win32clipboard.CloseClipboard()




if __name__ == '__main__':
	if len(sys.argv) > 1:
		PPrinterRoutine()

	Init() # load default settings and prepare saving directory

	# prepare listener
	# lis.Configure('MouseEventCallBack', OnMouseEvent) # this line will cause trouble! (maybe due to too frequent mouse event)
	lis.Configure('KeyboardEventCallBack', OnKeyboardEvent)
	lisAgent = lis.Start()

	# prepare printer
	printerAgent = threading.Thread(target = PrinterRoutine)
	printerAgent.daemon = True
	printerAgent.start()

	# prepare systray
	systrayAgent = threading.Thread(target = SystrayRoutine)
	systrayAgent.daemon = True
	systrayAgent.start()

	systrayAgent.join()