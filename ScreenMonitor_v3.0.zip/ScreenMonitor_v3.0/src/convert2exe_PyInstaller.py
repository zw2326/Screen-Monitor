import os
import sys

if __name__ == '__main__':
	os.system(r'python D:\Python2.7.3_win32\PyInstaller-2.1\pyinstaller.py ScreenMonitor.py' + ((' ' + sys.argv[1]) if len(sys.argv) > 1 else ''))