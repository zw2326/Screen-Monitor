# -*- coding:utf8 -*-
from PyQt4 import QtCore, QtGui
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys

class SysTray(QSystemTrayIcon):
	def __init__(self, icon = '', options = [], onQuit = None, parent = None):
		super(SysTray, self).__init__(parent)
		self.initObjects(icon, onQuit)
		self.setObjects(options)
		self.activated.connect(self.iconClicked)

	def initObjects(self, icon, onQuit):
		self.menu = QMenu()
		self.quitAction = QAction(u'Quit', self, triggered = self.exitApp)
		self.icon = QIcon(icon)
		self.onQuit = onQuit

	def setObjects(self, options):
		for option in options:
			self.menu.addAction(QAction(option[0], self, triggered = option[1]))
		self.menu.addAction(self.quitAction)
		self.setIcon(self.icon)
		self.setContextMenu(self.menu)

	def iconClicked(self, reason):
		if reason == 2 or reason == 3:
			pw = self.parent()
			if pw.isVisible():
				pw.hide()
			else:
				pw.show()

	def exitApp(self):
		if self.onQuit != None:
			self.onQuit(self)
		self.setVisible(False)
		qApp.quit()
		sys.exit()

if __name__ == "__main__":
	pass